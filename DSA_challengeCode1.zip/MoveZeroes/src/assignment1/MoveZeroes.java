/*Assignment no.1
 Move Zeroes
Given an integer array nums, move all 0's to the end of it while maintaining the relative order of the non-zero elements. 
 * 
 * 
 */

package assignment1;

public class MoveZeroes {
    public static void moveZeroes(int[] nums) {
        int i = 0; // Pointer to track the current non-zero element
        int j = 0; // Pointer to iterate through the array

        // Iterate through the array
        while (j < nums.length) {
            // If the current element is non-zero, move it to the front
            if (nums[j] != 0) {
                nums[i] = nums[j];
                i++;
            }
            j++;
        }

        // Fill the remaining positions with zeroes
        while (i < nums.length) {
            nums[i] = 0;
            i++;
        }
    }

    public static void main(String[] args) {
        int[] nums1 = {0, 1, 0, 3, 12};
        System.out.print("Input: ");
        printArray(nums1);
        moveZeroes(nums1);
        System.out.print("Output: ");
        printArray(nums1);

        int[] nums2 = {0};
        System.out.print("Input: ");
        printArray(nums2);
        moveZeroes(nums2);
        System.out.print("Output: ");
        printArray(nums2);
    }

    public static void printArray(int[] nums) {
        System.out.print("[");
        for (int i = 0; i < nums.length; i++) {
            System.out.print(nums[i]);
            if (i != nums.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("]");
    }
}

/*
**********OutPut********************
*Input: [0, 1, 0, 3, 12]
Output: [1, 3, 12, 0, 0]
Input: [0]
Output: [0]

 
*/